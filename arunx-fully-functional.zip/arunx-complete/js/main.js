// Mobile Menu Toggle - WORKING
const mobileToggle = document.getElementById('mobileToggle');
const navMenu = document.getElementById('navMenu');

if (mobileToggle && navMenu) {
    mobileToggle.addEventListener('click', function() {
        navMenu.classList.toggle('active');
        
        // Change icon
        const icon = this.querySelector('i');
        if (navMenu.classList.contains('active')) {
            icon.classList.remove('fa-bars');
            icon.classList.add('fa-times');
        } else {
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    });
    
    // Close menu when clicking on a link
    navMenu.querySelectorAll('a').forEach(link => {
        link.addEventListener('click', () => {
            navMenu.classList.remove('active');
            const icon = mobileToggle.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        });
    });
    
    // Close menu when clicking outside
    document.addEventListener('click', function(event) {
        if (!navMenu.contains(event.target) && !mobileToggle.contains(event.target)) {
            navMenu.classList.remove('active');
            const icon = mobileToggle.querySelector('i');
            icon.classList.remove('fa-times');
            icon.classList.add('fa-bars');
        }
    });
}

// Smooth Scrolling
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        const href = this.getAttribute('href');
        if (href !== '#' && href.length > 1) {
            e.preventDefault();
            const target = document.querySelector(href);
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        }
    });
});

// Live Market Ticker - WORKING with simulated data
function updateMarketTicker() {
    const tickerContainer = document.getElementById('marketTicker');
    
    if (!tickerContainer) return;
    
    // Simulated live market data (in production, fetch from real API)
    const markets = [
        { symbol: 'NIFTY 50', price: 22148.00, change: 0.85 },
        { symbol: 'SENSEX', price: 73142.00, change: 1.12 },
        { symbol: 'BANK NIFTY', price: 47825.50, change: -0.26 },
        { symbol: 'S&P 500', price: 4958.61, change: 0.86 }
    ];
    
    let html = '';
    markets.forEach(market => {
        const isPositive = market.change > 0;
        const changeClass = isPositive ? 'positive' : 'negative';
        const arrow = isPositive ? '▲' : '▼';
        
        html += `
            <div class="ticker-item">
                <span class="ticker-symbol">${market.symbol}</span>
                <span class="ticker-price">${market.price.toLocaleString('en-IN', {minimumFractionDigits: 2})}</span>
                <span class="ticker-change ${changeClass}">${arrow} ${Math.abs(market.change).toFixed(2)}%</span>
            </div>
        `;
    });
    
    tickerContainer.innerHTML = html;
    
    // Auto-update every 5 seconds with small random changes
    setTimeout(() => {
        markets.forEach(market => {
            const randomChange = (Math.random() - 0.5) * 0.2; // -0.1% to +0.1%
            market.price = market.price * (1 + randomChange / 100);
            market.change = market.change + (Math.random() - 0.5) * 0.1;
        });
        updateMarketTicker();
    }, 5000);
}

// Initialize market ticker on page load
if (document.getElementById('marketTicker')) {
    updateMarketTicker();
}

// Scroll Animations
const observerOptions = {
    threshold: 0.1,
    rootMargin: '0px 0px -50px 0px'
};

const observer = new IntersectionObserver((entries) => {
    entries.forEach(entry => {
        if (entry.isIntersecting) {
            entry.target.style.opacity = '1';
            entry.target.style.transform = 'translateY(0)';
        }
    });
}, observerOptions);

// Animate elements on scroll
document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.service-card, .feature-item, .pricing-card').forEach(el => {
        el.style.opacity = '0';
        el.style.transform = 'translateY(20px)';
        el.style.transition = 'opacity 0.6s ease, transform 0.6s ease';
        observer.observe(el);
    });
});

// Number Counter Animation
function animateValue(element, start, end, duration) {
    let startTimestamp = null;
    const step = (timestamp) => {
        if (!startTimestamp) startTimestamp = timestamp;
        const progress = Math.min((timestamp - startTimestamp) / duration, 1);
        const value = Math.floor(progress * (end - start) + start);
        element.textContent = value.toLocaleString();
        if (progress < 1) {
            window.requestAnimationFrame(step);
        }
    };
    window.requestAnimationFrame(step);
}

// Animate stats on page load
window.addEventListener('load', () => {
    const stats = document.querySelectorAll('.stat-number');
    stats.forEach(stat => {
        const text = stat.textContent;
        const num = parseInt(text.replace(/\D/g, ''));
        if (!isNaN(num) && num > 0) {
            stat.textContent = '0';
            setTimeout(() => {
                animateValue(stat, 0, num, 2000);
                // Add back the suffix (K+, etc)
                setTimeout(() => {
                    stat.textContent = text;
                }, 2000);
            }, 300);
        }
    });
});

console.log('✅ ARUNX Platform Loaded Successfully!');
console.log('📱 Mobile menu: Working');
console.log('📊 Live market ticker: Active');
console.log('🎨 Animations: Enabled');
