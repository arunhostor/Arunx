// Global Variables
let selectedTemplate = 'modern';
let resumeData = {};

// Step Navigation
function goToStep(stepNumber) {
    // Hide all step contents
    document.querySelectorAll('.step-content').forEach(content => {
        content.classList.remove('active');
    });
    
    // Show selected step content
    document.getElementById('step' + stepNumber).classList.add('active');
    
    // Update step indicators
    document.querySelectorAll('.step').forEach((step, index) => {
        if (index < stepNumber) {
            step.classList.add('active');
        } else {
            step.classList.remove('active');
        }
    });
    
    // Scroll to top
    window.scrollTo({ top: 0, behavior: 'smooth' });
}

// Template Selection
function selectTemplate(template) {
    selectedTemplate = template;
    console.log('Selected template:', template);
    goToStep(2);
}

// Add Experience Field
function addExperience() {
    const container = document.getElementById('experienceContainer');
    const newItem = document.createElement('div');
    newItem.className = 'experience-item';
    newItem.innerHTML = `
        <button type="button" class="remove-btn" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
        <div class="form-grid">
            <div class="form-group">
                <label>Job Title</label>
                <input type="text" class="exp-title" placeholder="Software Engineer">
            </div>
            <div class="form-group">
                <label>Company</label>
                <input type="text" class="exp-company" placeholder="Tech Corp">
            </div>
            <div class="form-group">
                <label>Start Date</label>
                <input type="month" class="exp-start">
            </div>
            <div class="form-group">
                <label>End Date</label>
                <input type="month" class="exp-end">
            </div>
            <div class="form-group full-width">
                <label>Description</label>
                <textarea class="exp-desc" rows="3" placeholder="Describe your responsibilities and achievements..."></textarea>
            </div>
        </div>
    `;
    container.appendChild(newItem);
}

// Add Education Field
function addEducation() {
    const container = document.getElementById('educationContainer');
    const newItem = document.createElement('div');
    newItem.className = 'education-item';
    newItem.innerHTML = `
        <button type="button" class="remove-btn" onclick="this.parentElement.remove()">
            <i class="fas fa-times"></i>
        </button>
        <div class="form-grid">
            <div class="form-group">
                <label>Degree</label>
                <input type="text" class="edu-degree" placeholder="Bachelor of Technology">
            </div>
            <div class="form-group">
                <label>Institution</label>
                <input type="text" class="edu-school" placeholder="University Name">
            </div>
            <div class="form-group">
                <label>Year</label>
                <input type="number" class="edu-year" placeholder="2020">
            </div>
        </div>
    `;
    container.appendChild(newItem);
}

// Collect Form Data
function collectFormData() {
    resumeData = {
        template: selectedTemplate,
        fullName: document.getElementById('fullName').value,
        jobTitle: document.getElementById('jobTitle').value,
        email: document.getElementById('email').value,
        phone: document.getElementById('phone').value,
        location: document.getElementById('location').value,
        linkedin: document.getElementById('linkedin').value,
        summary: document.getElementById('summary').value,
        experiences: [],
        education: [],
        skills: []
    };
    
    // Collect experiences
    document.querySelectorAll('.experience-item').forEach(item => {
        const exp = {
            title: item.querySelector('.exp-title').value,
            company: item.querySelector('.exp-company').value,
            start: item.querySelector('.exp-start').value,
            end: item.querySelector('.exp-end').value,
            description: item.querySelector('.exp-desc').value
        };
        if (exp.title || exp.company) {
            resumeData.experiences.push(exp);
        }
    });
    
    // Collect education
    document.querySelectorAll('.education-item').forEach(item => {
        const edu = {
            degree: item.querySelector('.edu-degree').value,
            school: item.querySelector('.edu-school').value,
            year: item.querySelector('.edu-year').value
        };
        if (edu.degree || edu.school) {
            resumeData.education.push(edu);
        }
    });
    
    // Collect skills
    const skillsInput = document.getElementById('skills').value;
    if (skillsInput) {
        resumeData.skills = skillsInput.split(',').map(s => s.trim()).filter(s => s);
    }
    
    return resumeData;
}

// Generate Resume Preview
function generatePreview(data) {
    const preview = document.getElementById('resumePreview');
    
    let html = `
        <div class="resume-header ${data.template}">
            <div class="resume-name">${data.fullName || 'Your Name'}</div>
            <div class="resume-job-title">${data.jobTitle || 'Your Job Title'}</div>
            <div class="resume-contact">
                ${data.email ? `<span><i class="fas fa-envelope"></i> ${data.email}</span>` : ''}
                ${data.phone ? `<span><i class="fas fa-phone"></i> ${data.phone}</span>` : ''}
                ${data.location ? `<span><i class="fas fa-map-marker-alt"></i> ${data.location}</span>` : ''}
                ${data.linkedin ? `<span><i class="fab fa-linkedin"></i> LinkedIn</span>` : ''}
            </div>
        </div>
    `;
    
    if (data.summary) {
        html += `
            <div class="resume-section">
                <h2 class="resume-section-title">Professional Summary</h2>
                <div class="resume-summary">${data.summary}</div>
            </div>
        `;
    }
    
    if (data.experiences && data.experiences.length > 0) {
        html += `
            <div class="resume-section">
                <h2 class="resume-section-title">Work Experience</h2>
        `;
        data.experiences.forEach(exp => {
            const startDate = exp.start ? new Date(exp.start).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : '';
            const endDate = exp.end ? new Date(exp.end).toLocaleDateString('en-US', { month: 'short', year: 'numeric' }) : 'Present';
            
            html += `
                <div class="experience-entry">
                    <div class="entry-header">
                        <div class="entry-title">${exp.title}</div>
                        <div class="entry-date">${startDate} - ${endDate}</div>
                    </div>
                    <div class="entry-company">${exp.company}</div>
                    <div class="entry-description">${exp.description}</div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    if (data.education && data.education.length > 0) {
        html += `
            <div class="resume-section">
                <h2 class="resume-section-title">Education</h2>
        `;
        data.education.forEach(edu => {
            html += `
                <div class="education-entry">
                    <div class="entry-header">
                        <div class="entry-title">${edu.degree}</div>
                        <div class="entry-date">${edu.year}</div>
                    </div>
                    <div class="entry-company">${edu.school}</div>
                </div>
            `;
        });
        html += '</div>';
    }
    
    if (data.skills && data.skills.length > 0) {
        html += `
            <div class="resume-section">
                <h2 class="resume-section-title">Skills</h2>
                <div class="skills-list">
        `;
        data.skills.forEach(skill => {
            html += `<span class="skill-tag">${skill}</span>`;
        });
        html += `
                </div>
            </div>
        `;
    }
    
    preview.innerHTML = html;
}

// Form Submit Handler
document.getElementById('resumeForm')?.addEventListener('submit', function(e) {
    e.preventDefault();
    const data = collectFormData();
    generatePreview(data);
    goToStep(3);
});

// Download Resume as PDF
function downloadResume() {
    const resumeContent = document.getElementById('resumePreview');
    const data = resumeData;
    
    // For now, we'll use window.print() which allows saving as PDF
    // In production, you'd use a library like jsPDF or html2pdf
    
    alert('Downloading Resume...\n\nTip: Use your browser\'s "Print to PDF" or "Save as PDF" option.\n\nFor automatic PDF generation, this feature requires a premium subscription.');
    
    // Create a print-friendly version
    const printWindow = window.open('', '', 'height=800,width=800');
    printWindow.document.write('<html><head><title>' + data.fullName + ' - Resume</title>');
    printWindow.document.write('<style>');
    printWindow.document.write(`
        body { font-family: Arial, sans-serif; padding: 2rem; }
        .resume-header { padding: 2rem; margin-bottom: 2rem; border-radius: 8px; }
        .resume-header.modern { background: linear-gradient(135deg, #667eea 0%, #764ba2 100%); color: white; }
        .resume-header.classic { background: #1f2937; color: white; }
        .resume-header.creative { background: linear-gradient(135deg, #f093fb 0%, #f5576c 100%); color: white; }
        .resume-header.minimal { background: #10b981; color: white; }
        .resume-name { font-size: 2rem; font-weight: bold; }
        .resume-job-title { font-size: 1.3rem; margin-bottom: 1rem; }
        .resume-contact { display: flex; gap: 1.5rem; flex-wrap: wrap; }
        .resume-section { margin-bottom: 2rem; }
        .resume-section-title { font-size: 1.3rem; color: #6366f1; border-bottom: 2px solid #6366f1; padding-bottom: 0.5rem; margin-bottom: 1rem; }
        .experience-entry, .education-entry { margin-bottom: 1.5rem; }
        .entry-header { display: flex; justify-content: space-between; }
        .entry-title { font-weight: bold; }
        .entry-company { color: #6366f1; font-weight: 600; }
        .skills-list { display: flex; flex-wrap: wrap; gap: 0.5rem; }
        .skill-tag { padding: 0.5rem 1rem; background: #f3f4f6; border-radius: 20px; }
    `);
    printWindow.document.write('</style></head><body>');
    printWindow.document.write(resumeContent.innerHTML);
    printWindow.document.write('</body></html>');
    printWindow.document.close();
    printWindow.print();
}

console.log('✅ Resume Builder Loaded Successfully!');
console.log('📝 Features: Template selection, Form builder, Live preview, PDF export');
