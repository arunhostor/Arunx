// RSS Feed Configuration
const RSS_FEEDS = [
    {
        name: 'TechCrunch',
        url: 'https://techcrunch.com/feed/',
        category: 'technology',
        color: '#0f9'
    },
    {
        name: 'Hacker News',
        url: 'https://hnrss.org/frontpage',
        category: 'technology',
        color: '#ff6600'
    },
    {
        name: 'BBC News',
        url: 'https://feeds.bbci.co.uk/news/rss.xml',
        category: 'world',
        color: '#bb1919'
    },
    {
        name: 'Reuters Business',
        url: 'https://www.reutersagency.com/feed/?taxonomy=best-topics&post_type=best',
        category: 'business',
        color: '#ff8000'
    },
    {
        name: 'The Verge',
        url: 'https://www.theverge.com/rss/index.xml',
        category: 'technology',
        color: '#fa4b2a'
    }
];

let allArticles = [];
let displayedArticles = [];
let currentCategory = 'all';

// Initialize News Feed
async function initNews() {
    console.log('🔄 Initializing news feed...');
    showLoading();
    
    try {
        await fetchAllFeeds();
        displayNews();
        updateBreakingNews();
        hideLoading();
        
        // Auto-refresh every 5 minutes
        setInterval(() => {
            fetchAllFeeds();
        }, 5 * 60 * 1000);
        
    } catch (error) {
        console.error('Error initializing news:', error);
        showError();
    }
}

// Fetch RSS Feeds using RSS2JSON API (Free service)
async function fetchAllFeeds() {
    console.log('📡 Fetching RSS feeds...');
    allArticles = [];
    
    const promises = RSS_FEEDS.map(feed => fetchFeed(feed));
    await Promise.all(promises);
    
    // Sort by date (newest first)
    allArticles.sort((a, b) => new Date(b.pubDate) - new Date(a.pubDate));
    
    console.log(`✅ Loaded ${allArticles.length} articles`);
}

// Fetch Single RSS Feed
async function fetchFeed(feed) {
    try {
        // Using RSS2JSON API (free service to convert RSS to JSON)
        const apiUrl = `https://api.rss2json.com/v1/api.json?rss_url=${encodeURIComponent(feed.url)}`;
        
        const response = await fetch(apiUrl);
        const data = await response.json();
        
        if (data.status === 'ok' && data.items) {
            data.items.forEach(item => {
                allArticles.push({
                    title: item.title,
                    description: item.description || item.content || 'Read more...',
                    link: item.link,
                    pubDate: item.pubDate,
                    source: feed.name,
                    category: feed.category,
                    color: feed.color
                });
            });
            console.log(`✓ Loaded ${data.items.length} articles from ${feed.name}`);
        }
    } catch (error) {
        console.error(`Error fetching ${feed.name}:`, error);
        // Continue with other feeds even if one fails
    }
}

// Display News Articles
function displayNews() {
    const container = document.getElementById('newsContent');
    if (!container) return;
    
    // Filter by category
    displayedArticles = currentCategory === 'all' 
        ? allArticles 
        : allArticles.filter(a => a.category === currentCategory);
    
    if (displayedArticles.length === 0) {
        container.innerHTML = `
            <div class="loading-indicator">
                <i class="fas fa-newspaper"></i>
                <p>No articles found. Try a different category.</p>
            </div>
        `;
        return;
    }
    
    let html = '';
    displayedArticles.forEach((article, index) => {
        const timeAgo = getTimeAgo(new Date(article.pubDate));
        const cleanDescription = stripHTML(article.description).substring(0, 200);
        
        html += `
            <article class="news-article" onclick="window.open('${article.link}', '_blank')">
                <div class="article-meta">
                    <span class="article-source" style="color: ${article.color}">${article.source}</span>
                    <span class="article-time">
                        <i class="fas fa-clock"></i>
                        ${timeAgo}
                    </span>
                </div>
                <h3>${article.title}</h3>
                <p>${cleanDescription}...</p>
                <a href="${article.link}" class="article-link" target="_blank" onclick="event.stopPropagation()">
                    Read full article <i class="fas fa-external-link-alt"></i>
                </a>
            </article>
        `;
    });
    
    container.innerHTML = html;
    
    // Show load more button if there are more articles
    const loadMoreBtn = document.getElementById('loadMoreBtn');
    if (loadMoreBtn) {
        loadMoreBtn.style.display = displayedArticles.length > 10 ? 'flex' : 'none';
    }
}

// Update Breaking News Ticker
function updateBreakingNews() {
    const ticker = document.getElementById('breakingNews');
    if (!ticker || allArticles.length === 0) return;
    
    // Get latest 5 headlines
    const headlines = allArticles.slice(0, 5).map(a => a.title).join(' • ');
    ticker.textContent = headlines;
}

// Helper Functions
function getTimeAgo(date) {
    const seconds = Math.floor((new Date() - date) / 1000);
    
    if (seconds < 60) return 'just now';
    if (seconds < 3600) return Math.floor(seconds / 60) + ' min ago';
    if (seconds < 86400) return Math.floor(seconds / 3600) + ' hours ago';
    return Math.floor(seconds / 86400) + ' days ago';
}

function stripHTML(html) {
    const tmp = document.createElement('div');
    tmp.innerHTML = html;
    return tmp.textContent || tmp.innerText || '';
}

function showLoading() {
    const indicator = document.getElementById('loadingIndicator');
    if (indicator) indicator.style.display = 'block';
}

function hideLoading() {
    const indicator = document.getElementById('loadingIndicator');
    if (indicator) indicator.style.display = 'none';
}

function showError() {
    const container = document.getElementById('newsContent');
    if (container) {
        container.innerHTML = `
            <div class="loading-indicator">
                <i class="fas fa-exclamation-triangle"></i>
                <p>Unable to load news feeds. Please check your internet connection and try again.</p>
                <button class="btn-primary" onclick="initNews()" style="margin-top: 1rem;">
                    <i class="fas fa-sync-alt"></i> Retry
                </button>
            </div>
        `;
    }
    hideLoading();
}

// Category Filtering
document.querySelectorAll('.category-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        currentCategory = this.getAttribute('data-category');
        displayNews();
    });
});

// Search Functionality
const searchInput = document.getElementById('newsSearch');
if (searchInput) {
    searchInput.addEventListener('input', function(e) {
        const query = e.target.value.toLowerCase();
        
        if (query.length === 0) {
            displayNews();
            return;
        }
        
        const filtered = displayedArticles.filter(article => 
            article.title.toLowerCase().includes(query) ||
            article.description.toLowerCase().includes(query)
        );
        
        const container = document.getElementById('newsContent');
        if (filtered.length === 0) {
            container.innerHTML = `
                <div class="loading-indicator">
                    <i class="fas fa-search"></i>
                    <p>No articles found for "${query}"</p>
                </div>
            `;
            return;
        }
        
        let html = '';
        filtered.forEach(article => {
            const timeAgo = getTimeAgo(new Date(article.pubDate));
            const cleanDescription = stripHTML(article.description).substring(0, 200);
            
            html += `
                <article class="news-article" onclick="window.open('${article.link}', '_blank')">
                    <div class="article-meta">
                        <span class="article-source" style="color: ${article.color}">${article.source}</span>
                        <span class="article-time"><i class="fas fa-clock"></i> ${timeAgo}</span>
                    </div>
                    <h3>${article.title}</h3>
                    <p>${cleanDescription}...</p>
                    <a href="${article.link}" class="article-link" target="_blank">
                        Read full article <i class="fas fa-external-link-alt"></i>
                    </a>
                </article>
            `;
        });
        container.innerHTML = html;
    });
}

// Newsletter Subscription
document.querySelector('.subscribe-btn')?.addEventListener('click', function() {
    const email = document.querySelector('.newsletter-input').value;
    if (email && email.includes('@')) {
        alert(`✓ Successfully subscribed!\n\nYou'll receive daily news digest at ${email}`);
        document.querySelector('.newsletter-input').value = '';
    } else {
        alert('Please enter a valid email address');
    }
});

// Initialize on page load
if (document.getElementById('newsContent')) {
    initNews();
}

console.log('✅ News Aggregator Loaded Successfully!');
console.log('📰 RSS Feeds: Active');
console.log('🔄 Auto-refresh: Every 5 minutes');
