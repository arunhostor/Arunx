// ===================================
// RESUME BUILDER - JavaScript
// ===================================

let currentZoom = 100;
let currentTemplate = 'professional';
let resumeData = {
    personal: {},
    summary: '',
    experience: [],
    education: [],
    skills: []
};

// Initialize
document.addEventListener('DOMContentLoaded', function() {
    // Select first template by default
    selectTemplate('professional');
    
    // Add skill on Enter key
    const skillInput = document.getElementById('skillInput');
    if (skillInput) {
        skillInput.addEventListener('keypress', function(e) {
            if (e.key === 'Enter') {
                e.preventDefault();
                addSkill();
            }
        });
    }
    
    // Load saved resume if exists
    loadSavedResume();
    
    // Add initial experience and education items
    addExperience();
    addEducation();
});

// Template Selection
function selectTemplate(template) {
    currentTemplate = template;
    
    // Update active state
    document.querySelectorAll('.template-option').forEach(option => {
        option.classList.remove('active');
    });
    
    const selectedOption = document.querySelector(`[data-template="${template}"]`);
    if (selectedOption && !selectedOption.classList.contains('premium')) {
        selectedOption.classList.add('active');
        
        // Update preview template
        const preview = document.getElementById('resumePreview');
        preview.className = `resume-preview ${template}`;
        
        updatePreview();
    }
}

// Add Experience
function addExperience() {
    const experienceList = document.getElementById('experienceList');
    const index = resumeData.experience.length;
    
    const experienceItem = document.createElement('div');
    experienceItem.className = 'form-section';
    experienceItem.style.background = 'var(--white)';
    experienceItem.style.marginBottom = 'var(--spacing-md)';
    experienceItem.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-md);">
            <strong>Experience #${index + 1}</strong>
            <button class="btn-icon" onclick="removeExperience(this)" style="background: var(--danger-color); color: white; border: none;">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        <div class="form-grid">
            <div class="form-group full-width">
                <label>Job Title</label>
                <input type="text" placeholder="e.g. Senior Developer" data-index="${index}" data-field="title" oninput="updateExperience(this)">
            </div>
            <div class="form-group">
                <label>Company</label>
                <input type="text" placeholder="e.g. Tech Corp" data-index="${index}" data-field="company" oninput="updateExperience(this)">
            </div>
            <div class="form-group">
                <label>Duration</label>
                <input type="text" placeholder="e.g. Jan 2020 - Present" data-index="${index}" data-field="duration" oninput="updateExperience(this)">
            </div>
            <div class="form-group full-width">
                <label>Description</label>
                <textarea rows="3" placeholder="Describe your responsibilities and achievements..." data-index="${index}" data-field="description" oninput="updateExperience(this)"></textarea>
            </div>
        </div>
    `;
    
    experienceList.appendChild(experienceItem);
    
    // Add to data
    resumeData.experience.push({
        title: '',
        company: '',
        duration: '',
        description: ''
    });
}

function removeExperience(button) {
    const item = button.closest('.form-section');
    const index = Array.from(item.parentNode.children).indexOf(item);
    resumeData.experience.splice(index, 1);
    item.remove();
    updatePreview();
}

function updateExperience(input) {
    const index = parseInt(input.dataset.index);
    const field = input.dataset.field;
    resumeData.experience[index][field] = input.value;
    updatePreview();
}

// Add Education
function addEducation() {
    const educationList = document.getElementById('educationList');
    const index = resumeData.education.length;
    
    const educationItem = document.createElement('div');
    educationItem.className = 'form-section';
    educationItem.style.background = 'var(--white)';
    educationItem.style.marginBottom = 'var(--spacing-md)';
    educationItem.innerHTML = `
        <div style="display: flex; justify-content: space-between; align-items: center; margin-bottom: var(--spacing-md);">
            <strong>Education #${index + 1}</strong>
            <button class="btn-icon" onclick="removeEducation(this)" style="background: var(--danger-color); color: white; border: none;">
                <i class="fas fa-trash"></i>
            </button>
        </div>
        <div class="form-grid">
            <div class="form-group full-width">
                <label>Degree</label>
                <input type="text" placeholder="e.g. Bachelor of Science in Computer Science" data-index="${index}" data-field="degree" oninput="updateEducation(this)">
            </div>
            <div class="form-group">
                <label>Institution</label>
                <input type="text" placeholder="e.g. MIT" data-index="${index}" data-field="institution" oninput="updateEducation(this)">
            </div>
            <div class="form-group">
                <label>Year</label>
                <input type="text" placeholder="e.g. 2015 - 2019" data-index="${index}" data-field="year" oninput="updateEducation(this)">
            </div>
        </div>
    `;
    
    educationList.appendChild(educationItem);
    
    // Add to data
    resumeData.education.push({
        degree: '',
        institution: '',
        year: ''
    });
}

function removeEducation(button) {
    const item = button.closest('.form-section');
    const index = Array.from(item.parentNode.children).indexOf(item);
    resumeData.education.splice(index, 1);
    item.remove();
    updatePreview();
}

function updateEducation(input) {
    const index = parseInt(input.dataset.index);
    const field = input.dataset.field;
    resumeData.education[index][field] = input.value;
    updatePreview();
}

// Skills Management
function addSkill() {
    const skillInput = document.getElementById('skillInput');
    const skill = skillInput.value.trim();
    
    if (skill && !resumeData.skills.includes(skill)) {
        resumeData.skills.push(skill);
        skillInput.value = '';
        renderSkills();
        updatePreview();
    }
}

function removeSkill(skill) {
    const index = resumeData.skills.indexOf(skill);
    if (index > -1) {
        resumeData.skills.splice(index, 1);
        renderSkills();
        updatePreview();
    }
}

function renderSkills() {
    const skillsList = document.getElementById('skillsList');
    skillsList.innerHTML = resumeData.skills.map(skill => `
        <div class="skill-tag">
            <span>${skill}</span>
            <button onclick="removeSkill('${skill}')">×</button>
        </div>
    `).join('');
}

// Update Preview
function updatePreview() {
    // Get personal info
    resumeData.personal = {
        name: document.getElementById('fullName')?.value || '',
        title: document.getElementById('jobTitle')?.value || '',
        email: document.getElementById('email')?.value || '',
        phone: document.getElementById('phone')?.value || '',
        location: document.getElementById('location')?.value || '',
        website: document.getElementById('website')?.value || ''
    };
    
    resumeData.summary = document.getElementById('summary')?.value || '';
    
    // Generate preview HTML
    const preview = document.getElementById('resumePreview');
    
    if (!resumeData.personal.name) {
        preview.innerHTML = `
            <div class="preview-placeholder">
                <i class="fas fa-file-alt"></i>
                <p>Start filling in your details to see the preview</p>
            </div>
        `;
        return;
    }
    
    let previewHTML = `
        <div class="resume-header">
            <div class="resume-name">${resumeData.personal.name}</div>
            <div class="resume-title">${resumeData.personal.title}</div>
            <div class="resume-contact">
                ${resumeData.personal.email ? `<span><i class="fas fa-envelope"></i> ${resumeData.personal.email}</span>` : ''}
                ${resumeData.personal.phone ? `<span><i class="fas fa-phone"></i> ${resumeData.personal.phone}</span>` : ''}
                ${resumeData.personal.location ? `<span><i class="fas fa-map-marker-alt"></i> ${resumeData.personal.location}</span>` : ''}
                ${resumeData.personal.website ? `<span><i class="fas fa-link"></i> ${resumeData.personal.website}</span>` : ''}
            </div>
        </div>
    `;
    
    // Summary
    if (resumeData.summary) {
        previewHTML += `
            <div class="resume-section">
                <div class="section-title">Professional Summary</div>
                <div class="resume-summary">${resumeData.summary}</div>
            </div>
        `;
    }
    
    // Experience
    if (resumeData.experience.some(exp => exp.title)) {
        previewHTML += `
            <div class="resume-section">
                <div class="section-title">Work Experience</div>
                ${resumeData.experience.filter(exp => exp.title).map(exp => `
                    <div class="experience-item">
                        <div class="item-header">
                            <div>
                                <div class="item-title">${exp.title}</div>
                                <div class="item-subtitle">${exp.company}</div>
                            </div>
                            <div class="item-date">${exp.duration}</div>
                        </div>
                        ${exp.description ? `<div class="item-description">${exp.description}</div>` : ''}
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    // Education
    if (resumeData.education.some(edu => edu.degree)) {
        previewHTML += `
            <div class="resume-section">
                <div class="section-title">Education</div>
                ${resumeData.education.filter(edu => edu.degree).map(edu => `
                    <div class="education-item">
                        <div class="item-header">
                            <div>
                                <div class="item-title">${edu.degree}</div>
                                <div class="item-subtitle">${edu.institution}</div>
                            </div>
                            <div class="item-date">${edu.year}</div>
                        </div>
                    </div>
                `).join('')}
            </div>
        `;
    }
    
    // Skills
    if (resumeData.skills.length > 0) {
        previewHTML += `
            <div class="resume-section">
                <div class="section-title">Skills</div>
                <div class="skills-list">
                    ${resumeData.skills.map(skill => `
                        <div class="skill-item">${skill}</div>
                    `).join('')}
                </div>
            </div>
        `;
    }
    
    preview.innerHTML = previewHTML;
}

// Zoom Controls
function zoomIn() {
    if (currentZoom < 150) {
        currentZoom += 10;
        applyZoom();
    }
}

function zoomOut() {
    if (currentZoom > 50) {
        currentZoom -= 10;
        applyZoom();
    }
}

function applyZoom() {
    const preview = document.getElementById('resumePreview');
    preview.style.transform = `scale(${currentZoom / 100})`;
    document.getElementById('zoomLevel').textContent = currentZoom + '%';
}

// Save Resume
function saveResume() {
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser') || '{}');
    
    if (!currentUser.email) {
        alert('Please login to save your resume');
        showLogin();
        return;
    }
    
    // Save to localStorage (in production, this would be an API call)
    const savedResumes = JSON.parse(localStorage.getItem('savedResumes') || '{}');
    const userResumes = savedResumes[currentUser.email] || [];
    
    const resumeName = prompt('Enter a name for this resume:', 'My Resume');
    if (!resumeName) return;
    
    userResumes.push({
        name: resumeName,
        template: currentTemplate,
        data: resumeData,
        lastModified: new Date().toISOString()
    });
    
    savedResumes[currentUser.email] = userResumes;
    localStorage.setItem('savedResumes', JSON.stringify(savedResumes));
    
    // Update user stats
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    if (users[currentUser.email]) {
        users[currentUser.email].resumesCreated = userResumes.length;
        localStorage.setItem('users', JSON.stringify(users));
        sessionStorage.setItem('currentUser', JSON.stringify(users[currentUser.email]));
    }
    
    alert('✅ Resume saved successfully!');
}

function loadSavedResume() {
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser') || '{}');
    if (!currentUser.email) return;
    
    const savedResumes = JSON.parse(localStorage.getItem('savedResumes') || '{}');
    const userResumes = savedResumes[currentUser.email] || [];
    
    if (userResumes.length > 0) {
        const lastResume = userResumes[userResumes.length - 1];
        // You could auto-load the last resume here
        console.log('Last saved resume:', lastResume.name);
    }
}

// Export to PDF
function exportPDF() {
    const currentUser = JSON.parse(sessionStorage.getItem('currentUser') || '{}');
    
    // Check if user has free plan and has already exported
    if (currentUser.plan === 'free') {
        const exportCount = parseInt(localStorage.getItem('freeExportCount_' + currentUser.email) || '0');
        
        if (exportCount >= 3) {
            unlockPremium();
            return;
        }
        
        localStorage.setItem('freeExportCount_' + currentUser.email, exportCount + 1);
        alert(`PDF export started! You have ${3 - exportCount - 1} free exports remaining.\n\nUpgrade to Premium for unlimited exports.`);
    }
    
    // In a real app, this would generate a PDF
    // For now, we'll simulate it
    alert('📄 Generating PDF...\n\nIn the full version, your resume would be downloaded as a PDF file.\n\nFor now, you can:\n1. Use browser Print > Save as PDF\n2. Or upgrade to get automatic PDF generation');
    
    // Open print dialog as workaround
    window.print();
}

// Premium Features
function unlockPremium() {
    const premiumModal = document.getElementById('premiumModal');
    premiumModal.style.display = 'block';
}

function closePremiumModal() {
    document.getElementById('premiumModal').style.display = 'none';
}

function upgradeToPremium() {
    window.location.href = '../../checkout.html?plan=premium&from=resume-builder';
}

// Close modal on outside click
window.addEventListener('click', function(event) {
    const premiumModal = document.getElementById('premiumModal');
    if (event.target === premiumModal) {
        closePremiumModal();
    }
});
