// Category Filtering
document.querySelectorAll('.category-btn').forEach(btn => {
    btn.addEventListener('click', function() {
        document.querySelectorAll('.category-btn').forEach(b => b.classList.remove('active'));
        this.classList.add('active');
        
        const category = this.getAttribute('data-category');
        console.log('Filtering by:', category);
        // In production, this would filter news articles
    });
});

// News Search
const newsSearch = document.getElementById('newsSearch');
if (newsSearch) {
    newsSearch.addEventListener('input', function(e) {
        const query = e.target.value.toLowerCase();
        // In production, this would search through articles
        console.log('Searching for:', query);
    });
}

// Load More News
const loadMoreBtn = document.querySelector('.load-more-btn');
if (loadMoreBtn) {
    loadMoreBtn.addEventListener('click', function() {
        this.innerHTML = '<i class="fas fa-spinner fa-spin"></i> Loading...';
        
        // Simulate loading
        setTimeout(() => {
            this.innerHTML = '<i class="fas fa-sync-alt"></i> Load More News';
            alert('More news articles loaded! In production, this would fetch from RSS feeds.');
        }, 1000);
    });
}

// Article Actions
document.querySelectorAll('.action-icon').forEach(btn => {
    btn.addEventListener('click', function(e) {
        e.stopPropagation();
        const action = this.textContent.trim();
        console.log('Action:', action);
        
        if (action.includes('Save')) {
            this.innerHTML = '<i class="fas fa-bookmark"></i> Saved';
            this.style.borderColor = '#10b981';
            this.style.color = '#10b981';
        } else if (action.includes('Share')) {
            alert('Share options:\n\n• Copy Link\n• Twitter\n• LinkedIn\n• Facebook\n• Email');
        }
    });
});

// Newsletter Subscription
const subscribeBtn = document.querySelector('.subscribe-btn');
if (subscribeBtn) {
    subscribeBtn.addEventListener('click', function() {
        const emailInput = this.previousElementSibling;
        const email = emailInput.value;
        
        if (email && email.includes('@')) {
            alert(`✓ Successfully subscribed!\n\nWe'll send daily news digest to ${email}`);
            emailInput.value = '';
        } else {
            alert('Please enter a valid email address');
        }
    });
}

// Customize RSS Sources
const customizeBtn = document.querySelector('.customize-btn');
if (customizeBtn) {
    customizeBtn.addEventListener('click', function() {
        alert('RSS Feed Customization:\n\n✓ Economic Times\n✓ TechCrunch\n✓ Bloomberg\n✓ Reuters\n✓ YourStory\n\n• The Hindu\n• Business Standard\n• Mint\n• Forbes India\n\nUpgrade to Premium to add custom RSS feeds!');
    });
}

// Premium Ad
const adBtn = document.querySelector('.ad-btn');
if (adBtn) {
    adBtn.addEventListener('click', function() {
        alert('Premium Benefits:\n\n✓ Ad-Free Experience\n✓ Exclusive Deep Dives\n✓ Early Access to News\n✓ Custom RSS Feeds\n✓ AI News Summaries\n✓ Priority Support\n\nJust ₹499/month!');
    });
}

// Auto-refresh quick updates every 30 seconds
function refreshUpdates() {
    const updates = document.querySelector('.quick-updates');
    if (updates) {
        const firstUpdate = updates.firstElementChild;
        if (firstUpdate) {
            firstUpdate.querySelector('.update-time').textContent = 'Just now';
        }
    }
}

setInterval(refreshUpdates, 30000);

console.log('News Aggregator Loaded Successfully');
