// Stock Market Chart Data
const stockData = {
    '1D': {
        labels: ['9:00', '10:00', '11:00', '12:00', '1:00', '2:00', '3:00'],
        data: [21950, 21980, 22020, 22050, 22080, 22120, 22148]
    },
    '1W': {
        labels: ['Mon', 'Tue', 'Wed', 'Thu', 'Fri'],
        data: [21500, 21750, 21900, 22000, 22148]
    },
    '1M': {
        labels: ['Week 1', 'Week 2', 'Week 3', 'Week 4'],
        data: [20800, 21200, 21600, 22148]
    },
    '3M': {
        labels: ['Nov', 'Dec', 'Jan', 'Feb'],
        data: [19500, 20500, 21500, 22148]
    },
    '1Y': {
        labels: ['Feb', 'Apr', 'Jun', 'Aug', 'Oct', 'Dec', 'Feb'],
        data: [17500, 18000, 18500, 19500, 20500, 21500, 22148]
    },
    '5Y': {
        labels: ['2020', '2021', '2022', '2023', '2024', '2025'],
        data: [12000, 15000, 17000, 19000, 21000, 22148]
    }
};

// Initialize Chart
let stockChart;
const ctx = document.getElementById('stockChart');

if (ctx) {
    const chartConfig = {
        type: 'line',
        data: {
            labels: stockData['1D'].labels,
            datasets: [{
                label: 'NIFTY 50',
                data: stockData['1D'].data,
                borderColor: '#6366f1',
                backgroundColor: 'rgba(99, 102, 241, 0.1)',
                borderWidth: 3,
                fill: true,
                tension: 0.4,
                pointRadius: 0,
                pointHoverRadius: 6,
                pointHoverBackgroundColor: '#6366f1',
                pointHoverBorderColor: '#fff',
                pointHoverBorderWidth: 2
            }]
        },
        options: {
            responsive: true,
            maintainAspectRatio: false,
            plugins: {
                legend: {
                    display: false
                },
                tooltip: {
                    mode: 'index',
                    intersect: false,
                    backgroundColor: 'rgba(0, 0, 0, 0.8)',
                    padding: 12,
                    cornerRadius: 8,
                    titleFont: {
                        size: 14,
                        weight: 'bold'
                    },
                    bodyFont: {
                        size: 13
                    },
                    callbacks: {
                        label: function(context) {
                            return 'Price: ₹' + context.parsed.y.toLocaleString('en-IN');
                        }
                    }
                }
            },
            scales: {
                x: {
                    grid: {
                        display: false
                    },
                    ticks: {
                        font: {
                            size: 12
                        }
                    }
                },
                y: {
                    grid: {
                        color: 'rgba(0, 0, 0, 0.05)'
                    },
                    ticks: {
                        callback: function(value) {
                            return '₹' + value.toLocaleString('en-IN');
                        },
                        font: {
                            size: 12
                        }
                    }
                }
            },
            interaction: {
                mode: 'index',
                intersect: false
            }
        }
    };

    stockChart = new Chart(ctx, chartConfig);
}

// Time Period Buttons
document.querySelectorAll('.time-btn').forEach(button => {
    button.addEventListener('click', function() {
        // Remove active class from all buttons
        document.querySelectorAll('.time-btn').forEach(btn => btn.classList.remove('active'));
        
        // Add active class to clicked button
        this.classList.add('active');
        
        // Get period
        const period = this.getAttribute('data-period');
        
        // Update chart
        if (stockChart && stockData[period]) {
            stockChart.data.labels = stockData[period].labels;
            stockChart.data.datasets[0].data = stockData[period].data;
            stockChart.update();
        }
    });
});

// Market Movers Tabs
document.querySelectorAll('.mover-tab').forEach(tab => {
    tab.addEventListener('click', function() {
        // Remove active class from all tabs
        document.querySelectorAll('.mover-tab').forEach(t => t.classList.remove('active'));
        
        // Add active class to clicked tab
        this.classList.add('active');
        
        const type = this.getAttribute('data-type');
        
        // In a real app, you would fetch different data based on type
        console.log('Loading:', type);
    });
});

// Stock Search
const searchInput = document.getElementById('stockSearch');
const searchBtn = document.querySelector('.search-btn');

if (searchBtn) {
    searchBtn.addEventListener('click', function() {
        const query = searchInput.value.trim();
        if (query) {
            // In a real app, this would search for stocks
            alert('Searching for: ' + query + '\n\nThis feature will connect to a real stock API in production.');
        }
    });
}

if (searchInput) {
    searchInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            searchBtn.click();
        }
    });
}

// Auto-update market data (simulated)
function updateMarketData() {
    const indices = document.querySelectorAll('.index-card');
    
    indices.forEach(card => {
        const value = card.querySelector('.index-value');
        const change = card.querySelector('.index-change');
        
        if (value && change) {
            // Simulate small price changes
            const currentPrice = parseFloat(value.textContent.replace(/[^0-9.]/g, ''));
            const randomChange = (Math.random() - 0.5) * 0.5; // -0.25% to +0.25%
            const newPrice = currentPrice + (currentPrice * randomChange / 100);
            
            // Update display
            const isPositive = randomChange > 0;
            value.textContent = newPrice.toFixed(2);
            
            // Add flash effect
            card.style.transition = 'background-color 0.3s';
            card.style.backgroundColor = isPositive ? 'rgba(16, 185, 129, 0.05)' : 'rgba(239, 68, 68, 0.05)';
            
            setTimeout(() => {
                card.style.backgroundColor = '';
            }, 300);
        }
    });
}

// Update every 5 seconds (in production, use WebSocket for real-time data)
setInterval(updateMarketData, 5000);

// Add animation to numbers on page load
document.addEventListener('DOMContentLoaded', function() {
    const animateValue = (element, start, end, duration) => {
        let startTimestamp = null;
        const step = (timestamp) => {
            if (!startTimestamp) startTimestamp = timestamp;
            const progress = Math.min((timestamp - startTimestamp) / duration, 1);
            element.textContent = Math.floor(progress * (end - start) + start).toLocaleString('en-IN');
            if (progress < 1) {
                window.requestAnimationFrame(step);
            }
        };
        window.requestAnimationFrame(step);
    };

    // Animate index values
    document.querySelectorAll('.index-value').forEach(el => {
        const endValue = parseFloat(el.textContent.replace(/,/g, ''));
        const startValue = endValue * 0.95;
        el.textContent = '0';
        animateValue(el, startValue, endValue, 1000);
    });
});

// Premium feature alert
document.querySelector('.upgrade-btn')?.addEventListener('click', function() {
    alert('Upgrade to Premium to unlock:\n\n✓ Portfolio Tracking\n✓ Real-time Alerts\n✓ AI Trading Signals\n✓ Advanced Analytics\n✓ Custom Watchlists\n\nStarting at just ₹499/month!');
});

console.log('Stock Market Dashboard Loaded Successfully');
