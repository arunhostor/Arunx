// ===================================
// ARUNX Platform - Main JavaScript
// ===================================

// Navigation Functions
function toggleMobileMenu() {
    const navLinks = document.querySelector('.nav-links');
    navLinks.style.display = navLinks.style.display === 'flex' ? 'none' : 'flex';
}

function scrollToProducts() {
    document.getElementById('products').scrollIntoView({ behavior: 'smooth' });
}

// Product Navigation
function goToProduct(product) {
    const routes = {
        'resume': 'products/resume/builder.html',
        'news': 'products/news/feed.html',
        'stocks': 'products/stocks/analyzer.html',
        'ebooks': 'products/ebooks/store.html'
    };
    
    window.location.href = routes[product] || '#';
}

// Waitlist Function
function joinWaitlist(product) {
    const productNames = {
        'news': 'News Hub',
        'stocks': 'Stock Analyzer',
        'ebooks': 'Ebook Library'
    };
    
    const email = prompt(`Join the waitlist for ${productNames[product]}!\n\nEnter your email address:`);
    
    if (email && validateEmail(email)) {
        // Store in localStorage for now (replace with API call later)
        const waitlist = JSON.parse(localStorage.getItem('waitlist') || '{}');
        if (!waitlist[product]) waitlist[product] = [];
        waitlist[product].push({
            email: email,
            timestamp: new Date().toISOString()
        });
        localStorage.setItem('waitlist', JSON.stringify(waitlist));
        
        alert(`✅ Success! You've been added to the ${productNames[product]} waitlist. We'll notify you when it launches!`);
    } else if (email) {
        alert('Please enter a valid email address.');
    }
}

// Email Validation
function validateEmail(email) {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
}

// Modal Functions
function showLogin() {
    const authModal = document.getElementById('authModal');
    const authContainer = document.getElementById('authContainer');
    
    authContainer.innerHTML = `
        <div class="auth-form">
            <h2 style="text-align: center; margin-bottom: 1.5rem; color: var(--gray-900);">
                Welcome Back
            </h2>
            <form onsubmit="handleLogin(event)">
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" id="loginEmail" required placeholder="you@example.com">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="loginPassword" required placeholder="Enter your password">
                </div>
                <button type="submit" class="btn-primary btn-block">Sign In</button>
                <p style="text-align: center; margin-top: 1rem; color: var(--gray-600);">
                    Don't have an account? 
                    <a href="#" onclick="showSignup(); return false;" style="color: var(--primary-color); font-weight: 600;">Sign Up</a>
                </p>
            </form>
        </div>
    `;
    
    authModal.style.display = 'block';
}

function showSignup(plan = 'free') {
    const authModal = document.getElementById('authModal');
    const authContainer = document.getElementById('authContainer');
    
    const planNames = {
        'free': 'Free Plan',
        'premium': 'Premium Plan - $19/month',
        'pro': 'Pro Plan - $49/month'
    };
    
    authContainer.innerHTML = `
        <div class="auth-form">
            <h2 style="text-align: center; margin-bottom: 0.5rem; color: var(--gray-900);">
                Create Your Account
            </h2>
            <p style="text-align: center; margin-bottom: 1.5rem; color: var(--gray-600);">
                Starting with: <strong style="color: var(--primary-color);">${planNames[plan]}</strong>
            </p>
            <form onsubmit="handleSignup(event, '${plan}')">
                <div class="form-group">
                    <label>Full Name</label>
                    <input type="text" id="signupName" required placeholder="John Doe">
                </div>
                <div class="form-group">
                    <label>Email Address</label>
                    <input type="email" id="signupEmail" required placeholder="you@example.com">
                </div>
                <div class="form-group">
                    <label>Password</label>
                    <input type="password" id="signupPassword" required placeholder="Create a strong password" minlength="8">
                </div>
                <div style="margin-bottom: 1rem;">
                    <label style="display: flex; align-items: center; gap: 0.5rem; cursor: pointer;">
                        <input type="checkbox" required>
                        <span style="font-size: 0.9rem; color: var(--gray-600);">
                            I agree to the Terms of Service and Privacy Policy
                        </span>
                    </label>
                </div>
                <button type="submit" class="btn-primary btn-block">Create Account</button>
                <p style="text-align: center; margin-top: 1rem; color: var(--gray-600);">
                    Already have an account? 
                    <a href="#" onclick="showLogin(); return false;" style="color: var(--primary-color); font-weight: 600;">Sign In</a>
                </p>
            </form>
        </div>
    `;
    
    authModal.style.display = 'block';
}

function closeAuthModal() {
    document.getElementById('authModal').style.display = 'none';
}

// Handle Login
function handleLogin(event) {
    event.preventDefault();
    
    const email = document.getElementById('loginEmail').value;
    const password = document.getElementById('loginPassword').value;
    
    // Temporary: Check localStorage for user
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    
    if (users[email] && users[email].password === password) {
        // Store session
        sessionStorage.setItem('currentUser', JSON.stringify(users[email]));
        
        alert('✅ Login successful!');
        closeAuthModal();
        
        // Redirect to dashboard
        window.location.href = 'dashboard.html';
    } else {
        alert('❌ Invalid email or password. Please try again.');
    }
}

// Handle Signup
function handleSignup(event, plan) {
    event.preventDefault();
    
    const name = document.getElementById('signupName').value;
    const email = document.getElementById('signupEmail').value;
    const password = document.getElementById('signupPassword').value;
    
    // Temporary: Store in localStorage
    const users = JSON.parse(localStorage.getItem('users') || '{}');
    
    if (users[email]) {
        alert('❌ An account with this email already exists. Please sign in instead.');
        return;
    }
    
    users[email] = {
        name: name,
        email: email,
        password: password, // In production, this would be hashed
        plan: plan,
        createdAt: new Date().toISOString(),
        resumesCreated: 0,
        profileStrength: 0
    };
    
    localStorage.setItem('users', JSON.stringify(users));
    sessionStorage.setItem('currentUser', JSON.stringify(users[email]));
    
    alert(`✅ Account created successfully! Welcome to Arunx, ${name}!`);
    closeAuthModal();
    
    // Redirect based on plan
    if (plan === 'free') {
        window.location.href = 'products/resume/builder.html';
    } else {
        window.location.href = 'checkout.html?plan=' + plan;
    }
}

// Check if user is logged in
function checkAuth() {
    const currentUser = sessionStorage.getItem('currentUser');
    if (currentUser) {
        // Update UI to show user is logged in
        const user = JSON.parse(currentUser);
        const navLinks = document.querySelector('.nav-links');
        if (navLinks) {
            const loginBtn = navLinks.querySelector('.btn-secondary');
            const signupBtn = navLinks.querySelector('.btn-primary');
            if (loginBtn && signupBtn) {
                loginBtn.style.display = 'none';
                signupBtn.textContent = user.name.split(' ')[0];
                signupBtn.onclick = () => window.location.href = 'dashboard.html';
            }
        }
    }
}

// Logout Function
function logout() {
    if (confirm('Are you sure you want to logout?')) {
        sessionStorage.removeItem('currentUser');
        window.location.href = 'index.html';
    }
}

// Close modal when clicking outside
window.onclick = function(event) {
    const modal = document.getElementById('authModal');
    if (event.target === modal) {
        closeAuthModal();
    }
}

// Initialize on page load
document.addEventListener('DOMContentLoaded', function() {
    checkAuth();
    
    // Add smooth scrolling to all anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            const href = this.getAttribute('href');
            if (href !== '#') {
                e.preventDefault();
                const target = document.querySelector(href);
                if (target) {
                    target.scrollIntoView({ behavior: 'smooth' });
                }
            }
        });
    });
});

// Form Styles (injected)
const formStyles = `
    <style>
        .auth-form {
            max-width: 400px;
            margin: 0 auto;
        }
        
        .form-group {
            margin-bottom: 1.25rem;
        }
        
        .form-group label {
            display: block;
            margin-bottom: 0.5rem;
            color: var(--gray-700);
            font-weight: 500;
        }
        
        .form-group input {
            width: 100%;
            padding: 0.75rem;
            border: 2px solid var(--gray-300);
            border-radius: var(--radius-md);
            font-size: 1rem;
            transition: all 0.3s ease;
        }
        
        .form-group input:focus {
            outline: none;
            border-color: var(--primary-color);
            box-shadow: 0 0 0 3px rgba(99, 102, 241, 0.1);
        }
    </style>
`;

// Inject form styles
if (!document.querySelector('#form-styles')) {
    const styleTag = document.createElement('div');
    styleTag.id = 'form-styles';
    styleTag.innerHTML = formStyles;
    document.head.appendChild(styleTag);
}
